import hashlib,json,os,pathlib,runpy,subprocess,sys,warnings
expected=json.loads('{"bin/test": "973e3cf784388b8e7821e4962da8eeb4b615447cd652af920452b322bd63588c", "bin/get_sympy.py": "3cae7463d72dd553101977101015a862c4ce2b93f17c7ae9712f0fd2ca287869", "sympy/utilities/runtests.py": "f3ebc3f4677d84d64b7e52ea5129522b2b5233fd2937fe5857fbe8244dfcf95c"}')
if os.getcwd()!='/testbed' or list(sys.version_info[:3])!=[3,6,15] or not sys.flags.isolated:
    raise RuntimeError('private runtime identity mismatch')
if sys.prefix!='/opt/p07-python36' or sys.executable!='/opt/p07-python36/bin/python3.6':
    raise RuntimeError('private interpreter prefix mismatch')
for relative,digest in expected.items():
    if hashlib.sha256((pathlib.Path('/testbed')/relative).read_bytes()).hexdigest()!=digest:
        raise RuntimeError('native runner source mismatch')
warnings.filterwarnings('ignore',category=UserWarning)
warnings.filterwarnings('ignore',category=SyntaxWarning)
sys.path[:0]=['/testbed/bin','/testbed']
import mpmath,sympy
mpath=pathlib.Path(mpmath.__file__)
if mpmath.__version__!='1.2.1' or not str(mpath).startswith('/opt/p07-python36/lib/python3.6/site-packages/mpmath/'):
    raise RuntimeError('mpmath dependency identity mismatch')
if hashlib.sha256(mpath.read_bytes()).hexdigest()!='46cd24a875e8dd00fb47c6a5cf28fd06878d4dfe7562446b8d23ca69ca65b413':
    raise RuntimeError('mpmath module differs from verified wheel')
if str(pathlib.Path(sympy.__file__).resolve())!='/testbed/sympy/__init__.py':
    raise RuntimeError('SymPy import does not resolve to target source')
child=subprocess.Popen([sys.executable,'-RV'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
try:
    child_output=child.communicate(timeout=15)[0]
except subprocess.TimeoutExpired:
    child.kill()
    child_output=child.communicate()[0]
    raise RuntimeError('native subprocess capability probe timed out')
identity={'version_info':list(sys.version_info[:3]),'executable':sys.executable,'prefix':sys.prefix,
    'isolated':sys.flags.isolated,'sympy_module':sympy.__file__,'mpmath_module':mpmath.__file__,
    'mpmath_version':mpmath.__version__,'mpmath_module_sha256':hashlib.sha256(mpath.read_bytes()).hexdigest(),
    'native_source_sha256':expected,'native_argv':['/testbed/bin/test', '-C', '--verbose', 'sympy/printing/tests/test_latex.py'],'warning_policy':['ignore::UserWarning','ignore::SyntaxWarning'],
    'child_RV_exit':child.returncode,'child_RV_output':child_output[:65536].decode(errors='replace'),
    'child_RV_output_sha256':hashlib.sha256(child_output).hexdigest(),'child_RV_output_truncated':len(child_output)>65536,
    'subprocess_hash_randomization':'unavailable_native_fallback' if child.returncode else 'native_child_startup_available_execution_not_attested'}
print('P07_RUNNER_IDENTITY='+json.dumps(identity,sort_keys=True),flush=True)
print('>>>>> Start Test Output',flush=True)
sys.argv=['/testbed/bin/test', '-C', '--verbose', 'sympy/printing/tests/test_latex.py']
try:
    runpy.run_path('/testbed/bin/test',run_name='__main__')
except SystemExit as exc:
    code=exc.code if type(exc.code) is int else 0 if exc.code is None else 1
else:
    code=0
print('\nP07_TEST_EXIT='+str(code),flush=True)
print('>>>>> End Test Output',flush=True)
raise SystemExit(code)
