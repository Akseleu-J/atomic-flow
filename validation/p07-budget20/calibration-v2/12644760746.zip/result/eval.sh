#!/bin/bash
exec 2>&1
set -uxo pipefail
export PYTHONPATH=/testbed:/testbed/src
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git -c core.fileMode=false diff e670ff76cbad80108bde9bab616b66771b8653cf
source /opt/miniconda3/bin/activate
conda activate testbed
git checkout e670ff76cbad80108bde9bab616b66771b8653cf testing/test_collection.py
git apply -v - <<'EOF_114329324912'
diff --git a/testing/test_collection.py b/testing/test_collection.py
--- a/testing/test_collection.py
+++ b/testing/test_collection.py
@@ -402,7 +402,7 @@ def pytest_collect_file(path, parent):
         )
         testdir.mkdir("sub")
         testdir.makepyfile("def test_x(): pass")
-        result = testdir.runpytest("--collect-only")
+        result = testdir.runpytest("--co")
         result.stdout.fnmatch_lines(["*MyModule*", "*test_x*"])
 
     def test_pytest_collect_file_from_sister_dir(self, testdir):
@@ -433,7 +433,7 @@ def pytest_collect_file(path, parent):
         p = testdir.makepyfile("def test_x(): pass")
         p.copy(sub1.join(p.basename))
         p.copy(sub2.join(p.basename))
-        result = testdir.runpytest("--collect-only")
+        result = testdir.runpytest("--co")
         result.stdout.fnmatch_lines(["*MyModule1*", "*MyModule2*", "*test_x*"])
 
 

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA testing/test_collection.py
p07_test_exit=$?; printf '\nP07_TEST_EXIT=%s\n' "$p07_test_exit"
: '>>>>> End Test Output'
git checkout e670ff76cbad80108bde9bab616b66771b8653cf testing/test_collection.py
