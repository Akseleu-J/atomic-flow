#!/bin/bash
exec 2>&1
set -uxo pipefail
export PYTHONPATH=/testbed:/testbed/src
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git -c core.fileMode=false diff 4787fd64a4ca0dba5528b5651bddd254102fe9f3
source /opt/miniconda3/bin/activate
conda activate testbed
git checkout 4787fd64a4ca0dba5528b5651bddd254102fe9f3 testing/io/test_saferepr.py
git apply -v - <<'EOF_114329324912'
diff --git a/testing/io/test_saferepr.py b/testing/io/test_saferepr.py
--- a/testing/io/test_saferepr.py
+++ b/testing/io/test_saferepr.py
@@ -154,3 +154,20 @@ def test_pformat_dispatch():
     assert _pformat_dispatch("a") == "'a'"
     assert _pformat_dispatch("a" * 10, width=5) == "'aaaaaaaaaa'"
     assert _pformat_dispatch("foo bar", width=5) == "('foo '\n 'bar')"
+
+
+def test_broken_getattribute():
+    """saferepr() can create proper representations of classes with
+    broken __getattribute__ (#7145)
+    """
+
+    class SomeClass:
+        def __getattribute__(self, attr):
+            raise RuntimeError
+
+        def __repr__(self):
+            raise RuntimeError
+
+    assert saferepr(SomeClass()).startswith(
+        "<[RuntimeError() raised in repr()] SomeClass object at 0x"
+    )

EOF_114329324912
: '>>>>> Start Test Output'
python -c 'import hashlib,json,pathlib,sys; expected=json.loads('"'"'{"src/_pytest/_code/code.py": "ab7fc5f6ca95cc0eb2be4baac41fd3e0ac2ab56ad9c5ecffe4796040cf944db5", "src/_pytest/nodes.py": "a2bf4e47edaa8c5384eef9e555c95edc689fe5a3c3c73be797b266ad13bf4a45", "src/_pytest/python.py": "d86b91fd968ee9630e67047d6147757c73fd9eaca50479d2921e381158467f67", "src/_pytest/reports.py": "ac53786a3208cc10cb4232382090dc55b0730976fdc380415759eeada01f3da5", "testing/conftest.py": "cdec2ef20a07011572da652e5aa08c74b1f518cd54c73824c4ac6753d4335d55", "testing/io/test_saferepr.py": "15c33fbfe55c121caa7b9aa749c04fd0c772f91de9b8d6508e4bb9a290d0bf36", "tox.ini": "1826cce79332a3b0f503d730516351c99616718a8e14f203a3af0447095f2356"}'"'"'); actual={p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in expected}; actual==expected or sys.exit('"'"'pinned runner/protected source mismatch'"'"'); print('"'"'P07_REVIEWED_SOURCE_SHA256='"'"'+json.dumps(actual,sort_keys=True))' || exit 91
pytest -rA --tb=short testing/io/test_saferepr.py
p07_test_exit=$?; printf '\nP07_TEST_EXIT=%s\n' "$p07_test_exit"
: '>>>>> End Test Output'
git checkout 4787fd64a4ca0dba5528b5651bddd254102fe9f3 testing/io/test_saferepr.py
