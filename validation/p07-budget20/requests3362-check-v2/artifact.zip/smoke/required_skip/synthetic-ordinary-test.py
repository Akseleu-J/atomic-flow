
import json,os,ssl,urllib.error,urllib.request,warnings
import pytest
from pytest_httpbin import certs

def request(server,context=None):
    handlers=[urllib.request.ProxyHandler({})]
    if context is not None:
        handlers.append(urllib.request.HTTPSHandler(context=context))
    with urllib.request.build_opener(*handlers).open(server.url+'/get?health=p07',timeout=3) as response:
        if response.status!=200:
            raise RuntimeError('real HTTPBin status mismatch')
        result=json.loads(response.read(65536).decode())
    if result.get('args')!={'health':'p07'}:
        raise RuntimeError('real HTTPBin payload mismatch')

def test_legacy_apis():
    pytest.raises(ValueError,"int('p07-not-an-integer')")
    with pytest.warns(UserWarning):
        warnings.warn('p07 synthetic warning',UserWarning)

def test_real_http(httpbin):
    if httpbin.host!='127.0.0.1' or httpbin.protocol!='http':
        raise RuntimeError('HTTP fixture is not real loopback')
    request(httpbin)

def test_ca_verified_https(httpbin_secure,httpbin_ca_bundle):
    if httpbin_ca_bundle is not None or os.environ.get('REQUESTS_CA_BUNDLE')!=certs.where():
        raise RuntimeError('original CA fixture semantics changed')
    if httpbin_secure.host!='127.0.0.1' or httpbin_secure.protocol!='https':
        raise RuntimeError('HTTPS fixture is not real loopback')
    context=ssl.create_default_context(cafile=certs.where())
    if not context.check_hostname or context.verify_mode!=ssl.CERT_REQUIRED:
        raise RuntimeError('TLS verification disabled')
    request(httpbin_secure,context)
    wrong=ssl.create_default_context(cafile='/testbed/p07_private_wrongca.pem')
    try:
        request(httpbin_secure,wrong)
    except urllib.error.URLError as error:
        if not isinstance(error.reason,(ssl.SSLError,ssl.CertificateError)):
            raise
    else:
        raise RuntimeError('unrelated CA unexpectedly accepted')


@pytest.mark.skip(reason='synthetic required-test skip must refuse')
def test_required_production_value():
    assert False
